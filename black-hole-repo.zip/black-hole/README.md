# black-hole

A real-time black hole in one HTML file. Three.js r143 via import maps, no build step, no dependencies to install. Drop it on any static host and it runs.

**[Live demo](https://your-site.netlify.app)** · replace this link once you deploy

## What it does

Four passes per frame, all `ShaderMaterial`, no post-processing library.

**1 · Noise bake.** A one-off 256×256 float render target holding four octaves of tiling 3D Perlin noise at 5×, 10×, 20× and 40×, packed one octave per RGBA channel. Baked once at startup, never touched again. Falls back to a byte target where `OES_texture_float_linear` is missing, which is most Android hardware.

**2 · Main scene.** The accretion disk is a zero-height open cylinder — inner radius 1.5, outer 6. Its shader samples the four noise octaves at four different scroll speeds, takes the length of the result as turbulence, offsets the radial UV by it, and reads a 1×128 canvas gradient running white → amber → orange → magenta → violet. Behind it, 10,000 additive point sprites on a sphere of radius 400.

**3 · Distortion map.** Two grayscale quads in a separate scene: a camera-facing plane for the event horizon, and a horizontal plane three times larger for the disk's own smear. Additively blended into their own render target. This is the lensing field.

**4 · Composite.** A full-screen shader drags UVs toward the singularity's projected screen position in proportion to the distortion map, then applies chromatic aberration on three taps, a vignette, and brightness-scaled film grain. The Dither toggle swaps the output for 1-bit monochrome through a 4×4 Bayer matrix.

The plate annotation over the render is live — inclination is the camera's actual polar angle, range is its orbital radius with one world unit read as one Schwarzschild radius.

## Running it

```bash
python3 -m http.server 8000
# then open http://localhost:8000
```

Opening `index.html` directly usually works too, but some browsers refuse cross-origin module imports from a `file://` origin, so the local server is the reliable path.

## Deploying

Netlify picks it up as-is — `netlify.toml` sets the publish directory to the repo root. Drag-and-drop the folder or connect the repo; there is no build command.

## Tuning

Constants live at the top of the module in `index.html`.

| Constant | Default | What it does |
| --- | --- | --- |
| `ROLL_SPEED` | `0.0008` | Camera roll per frame. ~130s per revolution. |
| `DRIFT_AMPLITUDE` | `0.1` | Idle drift of the camera rig. |
| `LENS_STRENGTH` | `0.2` | How hard the distortion map bends the image. |
| `ABERRATION` | `0.02` | Chromatic aberration at full vignette. |
| `GRAIN` | `0.5` | Film grain multiplier. |
| `NOISE_SIZE` | `256` | Baked noise resolution. |
| `STAR_COUNT` | `10000` | Point sprites. First thing to cut on low-end mobile. |

The disk gradient stops are in the `gradientCanvas` block. Changing those changes the whole mood faster than anything else in the file.

## Credits

Built from a spec published as a [gist by Paramchoudhary](https://gist.github.com/Paramchoudhary/643a04cf4d8583750995b17edc65728c).

Periodic Perlin noise is Stefan Gustavson's `pnoise` from [webgl-noise](https://github.com/stegu/webgl-noise), MIT.

Orbit controls are written inline rather than pulled from `examples/jsm`, so the file needs only three.js core.

## Licence

MIT. See [LICENSE](LICENSE).
